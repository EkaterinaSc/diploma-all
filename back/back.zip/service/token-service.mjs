import dotenv from 'dotenv';
dotenv.config();
import jwt from 'jsonwebtoken';
import Token from "../models/tokenModel.mjs";

export default class TokenService {
    generateToken(info) {
        const accessToken = jwt.sign(info, process.env.SECRET_ACCESS_TOKEN, {expiresIn: '60m'});
        const refreshToken = jwt.sign(info, process.env.SECRET_REFRESH_TOKEN, {expiresIn: '60d'});
        console.log('[generateToken] accessToken:', accessToken);
        console.log('[generateToken] refreshToken:', refreshToken);
        return {
            accessToken,
            refreshToken
        }
    }

    async saveToken(userId, refreshToken) {
        const tokenData = await Token.findByPk(userId);
         if (tokenData) {
             console.log('🔄 Найден существующий в БД refreshToken:', tokenData.refreshToken);
             tokenData.refreshToken = refreshToken;
             const updated = await tokenData.save();
             console.log('Токен обновлён вручную через сейв', updated)
             return updated;
        }

        try {
            const newToken = await Token.create({ userId, refreshToken });
            console.log('[saveToken] созданный refreshToken в БД:', newToken.refreshToken);
            return newToken;
        } catch (err) {
            console.error('❌ Ошибка при создании токена:', err);
            throw err;
        }
    }


    async removeToken(refreshToken, userId) {
        console.log('refreshToken',refreshToken);
        const tokenData = await Token.findByPk(userId);
        console.log('tokenData', tokenData);

        const number = await Token.destroy({where: {userId: userId}});
        console.log('number', number);
        return tokenData;
    }

    validateAccessToken(accessToken) {
        try {
            const userData = jwt.verify(accessToken, process.env.SECRET_ACCESS_TOKEN);
            return userData;
        } catch (e) {
            return null;
        }
    }

    validateRefreshToken(refreshToken) {
        try {
            const userData = jwt.verify(refreshToken, process.env.SECRET_REFRESH_TOKEN);
            return userData;
        } catch (e) {
            return null;
        }
    }
    async findToken(refreshToken) {
        console.log('refreshToken поступивший в функцию из куки',refreshToken);
        const tokens = await Token.findAll();
        console.log('tokens в базе данных:', tokens);

        const tokenData = await Token.findOne({where: {refreshToken: refreshToken}});
        console.log('tokenData', tokenData);
       return tokenData;
    }



}