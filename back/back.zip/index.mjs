import express from 'express';
import * as process from "node:process";
import dotenv from 'dotenv';
dotenv.config();

import cors from 'cors';
import cookieParser from 'cookie-parser';
import sequelize from "./db.mjs";
import router from "./routes/userRoute.mjs";
import "./models/relations.mjs";
import errFunction from "./middleware/error-mdw.mjs";

const port = process.env.PORT || 5000;
const app = express();

app.use(express.json());
app.use(cookieParser());
app.use(cors());
app.use('/users', router);
app.use(errFunction); // должен идти последним из middleware

const start = async () => {
    try {
        await sequelize.authenticate();
        console.log('Подключено к MariaDB');

        await sequelize.sync({ alter: true });
        console.log('Таблицы синхронизированы');

        app.listen(port, () => {
            console.log(`Сервер работает на http://localhost:${port}`);
        });
    } catch (err) {
        console.error('Ошибка подключения к базе данных:', err);
    }
}

start();